<?php
if($_FILES["upload_file"]["name"] != '')
{
 $data = explode(".", $_FILES["upload_file"]["name"]);
 $extension = $data[1];
 $allowed_extension = array("jpg", "png", "gif", "docx", "jpeg", "mp3", "mp4", "wmv", "flv", "avi", "mov", "mpg", "jif", "pdf", "pptx", "xlsx", "xls");
 if(in_array($extension, $allowed_extension))
 {
  $new_file_name = rand() . '.' . $extension;
  $path = $_POST["hidden_folder_name"] . '/' . $new_file_name;
  if(move_uploaded_file($_FILES["upload_file"]["tmp_name"], $path))
  {
   echo 'File Uploaded';
  }
  else
  {
   echo 'An Error Was Encountered';
  }
  }
  else
  {
  echo 'Invalid File Type. Error Code: 0001';
  }
  }
  else
  {
  echo 'Please Selects A File';
  }
?>