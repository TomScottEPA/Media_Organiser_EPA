<!DOCTYPE html>
<html>
 <head>
  <title>Media Organiser</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="icon" href="/favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="styles.css" />
 </head>
 <body>
     <header>
         <img src="cloud.png" />
         <h1>Media Organiser</h1>
     </header>
     <!-- This will be the main body of the application where the majority of the content goes. -->
     <main>
        <div class="top_bar">
            <h2>Your Uploaded Media</h2>
            <button type="button" name="create_folder" id="create_folder" class="create_folder">Create A New Folder</button>
        </div>
            <div class="main_container">
                <div id="folder_table">
                </div>
                
                <!-- Create a new folder Modal -->
                
                <div id="folderModal" class="modal" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal_content">
                            <div class="modal_header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal_title" id="change_title">Create Folder</h4>
                            </div>
                            <div class="modal_body">
                                <p>Enter A Folder Name:
                                    <input type="text" name="folder_name" id="folder_name" class="folder_name" />
                                </p>
                                <input type="button" name="folder_button" id="folder_button" class="create_folder_btn" value="Create" />
                            <br />
                                <input type="hidden" name="action" id="action" />
                                <input type="hidden" name="old_name" id="old_name" />
                            </div>
                            <div class="modal_footer">
                            </div>
                        </div>
                    </div>
                </div>
                
                
                
                <div id="uploadModal" class="modal" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal_content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal_title">Upload A New File</h4>
                            </div>
                            <div class="modal_body">
                                <form method="post" id="upload_form" enctype='multipart/form-data'>
                                    <p>Select A File
                                    <input type="file" name="upload_file" class="select_file" />
                                    </p>
                                <br />
                                    <input type="hidden" name="hidden_folder_name" id="hidden_folder_name" />
                                    <input type="submit" name="upload_button" class="confirm_btn" value="Upload" />
                                </form>
                            </div>
                            <div class="modal-footer">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div id="filelistModal" class="modal" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal_content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal_title">File List</h4>
                            </div>
                            <div class="modal-body" id="file_list"></div>
                            <div class="modal-footer">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <footer>
            <!-- This application will not have a footer -->
        </footer>
    </body>
</html>

<script>
$(document).ready(function(){
 
 load_folder_list();
 
 function load_folder_list()
 {
  var action = "fetch";
  $.ajax({
   url:"action.php",
   method:"POST",
   data:{action:action},
   success:function(data)
   {
    $('#folder_table').html(data);
   }
  });
 }
 
 $(document).on('click', '#create_folder', function(){
  $('#action').val("create");
  $('#folder_name').val('');
  $('#folder_button').val('Create');
  $('#folderModal').modal('show');
  $('#old_name').val('');
  $('#change_title').text("New Folder");
 });
 
 $(document).on('click', '#folder_button', function(){
  var folder_name = $('#folder_name').val();
  var old_name = $('#old_name').val();
  var action = $('#action').val();
  if(folder_name != '')
  {
   $.ajax({
    url:"action.php",
    method:"POST",
    data:{folder_name:folder_name, old_name:old_name, action:action},
    success:function(data)
    {
     $('#folderModal').modal('hide');
     load_folder_list();
     alert(data);
    }
   });
  }
  else
  {
   alert("Please insert a folder name:");
  }
 });
 
 $(document).on("click", ".update", function(){
  var folder_name = $(this).data("name");
  $('#old_name').val(folder_name);
  $('#folder_name').val(folder_name);
  $('#action').val("change");
  $('#folderModal').modal("show");
  $('#folder_button').val('Update');
  $('#change_title').text("Change Folder Name");
 });
 
 $(document).on("click", ".delete_folder", function(){
  var folder_name = $(this).data("name");
  var action = "delete_folder";
  if(confirm("Are you sure you want to remove this folder?"))
  {
   $.ajax({
    url:"action.php",
    method:"POST",
    data:{folder_name:folder_name, action:action},
    success:function(data)
    {
     load_folder_list();
     alert(data);
    }
   });
  }
 });
 
 $(document).on('click', '.upload', function(){
  var folder_name = $(this).data("name");
  $('#hidden_folder_name').val(folder_name);
  $('#uploadModal').modal('show');
 });
 
 $('#upload_form').on('submit', function(){
  $.ajax({
   url:"upload.php",
   method:"POST",
   data: new FormData(this),
   contentType: false,
   cache: false,
   processData:false,
   success: function(data)
   { 
    load_folder_list();
    alert(data);
   }
  });
 });
    
$(document).on('blur', '.change_file_name', function(){
  var folder_name = $(this).data("folder_name");
  var old_file_name = $(this).data("file_name");
  var new_file_name = $(this).text();
  var action = "change_file_name";
  $.ajax({
   url:"action.php",
   method:"POST",
   data:{folder_name:folder_name, old_file_name:old_file_name, new_file_name:new_file_name, action:action},
   success:function(data)
   {
    alert(data);
   }
  });
 });

$(document).on('click', '.remove_file', function(){
  var path = $(this).attr("id");
  var action = "remove_file";
  if(confirm("Do you want to remove this file?"))
  {
   $.ajax({
    url:"action.php",
    method:"POST",
    data:{path:path, action:action},
    success:function(data)
    {
     alert(data);
     $('#filelistModal').modal('hide');
     load_folder_list();
    }
   });
  }
 });
    
/* Script for view files inside a folder */
 
 $(document).on('click', '.view_files', function(){
  var folder_name = $(this).data("name");
  var action = "fetch_files";
  $.ajax({
   url:"action.php",
   method:"POST",
   data:{action:action, folder_name:folder_name},
   success:function(data)
   {
    $('#file_list').html(data);
    $('#filelistModal').modal('show');
   }
  });
 });
 
});
</script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>